import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/database.types';

const supabaseUrl = 'https://wzckkgrshhjxmsfcxpal.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind6Y2trZ3JzaGhqeG1zZmN4cGFsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzg4MTAxNjksImV4cCI6MjA1NDM4NjE2OX0.cnwAk153i0sT_lRUgvWjFM36Ws0AqrtJkRPz_xyS3ZA';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase credentials');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);