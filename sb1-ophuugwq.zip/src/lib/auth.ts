import { supabase } from './supabase';

export type AuthError = {
  message: string;
};

export async function signUp(email: string, password: string): Promise<{ error: AuthError | null }> {
  const { error } = await supabase.auth.signUp({
    email,
    password,
  });

  if (error) {
    return { error: { message: error.message } };
  }

  return { error: null };
}

export async function signIn(email: string, password: string): Promise<{ error: AuthError | null }> {
  const { error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    return { error: { message: error.message } };
  }

  return { error: null };
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

export async function updateProfile(profile: {
  username?: string;
  full_name?: string;
  avatar_url?: string;
}) {
  const user = await getCurrentUser();
  if (!user) return { error: { message: 'Not authenticated' } };

  const { error } = await supabase
    .from('profiles')
    .update(profile)
    .eq('id', user.id);

  if (error) {
    return { error: { message: error.message } };
  }

  return { error: null };
}

export async function getProfile(userId: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) {
    return { error: { message: error.message } };
  }

  return { data, error: null };
}