import React, { useState, useEffect } from 'react';
import { Bot, Zap, ArrowRight, Menu, X, Sparkles, Code, BookOpen, MessageSquare, Laptop, Palette, Gauge, Wand2, Layout, Blocks, CheckCircle, Cpu, Globe, Shield, Users, Rocket, Settings, Search, Monitor, Bell, User, Info } from 'lucide-react';

const ThemeContext = React.createContext({
  theme: 'dark',
  setTheme: (theme: string) => {},
});

const LanguageContext = React.createContext({
  language: 'English (US)',
  setLanguage: (language: string) => {},
});

interface NavLinkProps {
  icon: React.ReactNode;
  text: string;
  mobile?: boolean;
}

function NavLink({ icon, text, mobile = false }: NavLinkProps) {
  return (
    <a 
      href="#" 
      className={`
        flex items-center gap-2 text-emerald-100 hover:text-emerald-400 transition-colors
        ${mobile ? 'text-lg py-2' : 'text-sm'}
      `}
    >
      {icon}
      <span>{text}</span>
    </a>
  );
}

interface StepCardProps {
  number: string;
  icon: React.ReactNode;
  title: string;
  description: string;
}

function StepCard({ number, icon, title, description }: StepCardProps) {
  return (
    <div className="backdrop-blur-lg bg-white/5 rounded-xl p-8 border border-emerald-900/20 hover:border-emerald-500/30 transition-all duration-300 hover:-translate-y-2">
      <div className="text-4xl font-bold text-emerald-400 mb-6">{number}</div>
      <div className="text-emerald-400 mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-white mb-4">{title}</h3>
      <p className="text-emerald-100/80">{description}</p>
    </div>
  );
}

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeFeature, setActiveFeature] = useState(0);
  const [activeDemo, setActiveDemo] = useState(0);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [theme, setTheme] = useState('dark');
  const [language, setLanguage] = useState('English (US)');
  const [notifications, setNotifications] = useState(true);
  const [activeSettingsTab, setActiveSettingsTab] = useState('general');
  const [searchQuery, setSearchQuery] = useState('');

  const languages = [
    'English (US)',
    'Español',
    'Français',
    'Deutsch',
    'Italiano',
    '日本語',
    '한국어',
    '中文'
  ];

  const features = [
    {
      icon: <Layout className="w-12 h-12 text-emerald-400" />,
      title: "Smart Layout Generation",
      description: "AI analyzes your needs and generates the perfect layout structure in seconds.",
      image: "https://images.unsplash.com/photo-1618788372246-79faff0c3742?auto=format&fit=crop&q=80&w=2000"
    },
    {
      icon: <Palette className="w-12 h-12 text-emerald-400" />,
      title: "Intelligent Design System",
      description: "Automatically creates a cohesive design system with colors, typography, and components.",
      image: "https://images.unsplash.com/photo-1545235617-9465d2a55698?auto=format&fit=crop&q=80&w=2000"
    },
    {
      icon: <Blocks className="w-12 h-12 text-emerald-400" />,
      title: "Component Library",
      description: "Access thousands of pre-built components that adapt to your brand.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=2000"
    }
  ];

  const demoSteps = [
    {
      title: "Input Your Requirements",
      description: "Describe your website needs in natural language",
      preview: "https://images.unsplash.com/photo-1607705703571-c5a8695f18f6?auto=format&fit=crop&q=80&w=2000"
    },
    {
      title: "AI Design Generation",
      description: "Watch as AI creates your custom design in real-time",
      preview: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&q=80&w=2000"
    },
    {
      title: "Instant Preview",
      description: "See your website come to life instantly",
      preview: "https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&q=80&w=2000"
    }
  ];

  const benefits = [
    { icon: <Rocket />, title: "Lightning Fast", description: "Launch your website in minutes, not days" },
    { icon: <Shield />, title: "SEO Optimized", description: "Built-in best practices for maximum visibility" },
    { icon: <Globe />, title: "Responsive Design", description: "Perfect on all devices and screen sizes" },
    { icon: <Users />, title: "User-Centric", description: "Optimized for the best user experience" },
    { icon: <Cpu />, title: "AI-Powered", description: "Smart features that adapt to your needs" },
    { icon: <CheckCircle />, title: "Production Ready", description: "Enterprise-grade reliability and performance" }
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % features.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveDemo((prev) => (prev + 1) % demoSteps.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const SettingsPanel = () => {
    if (!isSettingsOpen) return null;

    return (
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-start justify-end settings-backdrop-enter"
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            setIsSettingsOpen(false);
          }
        }}
      >
        <div 
          className="w-full max-w-md h-full bg-gradient-to-b from-gray-900 to-gray-950 shadow-2xl settings-panel-enter"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="h-full flex flex-col">
            <div className="p-6 border-b border-gray-800/50 bg-gray-900/50 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-green-300 text-transparent bg-clip-text">Settings</h2>
                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="text-gray-400 hover:text-emerald-400 transition-colors p-2 hover:bg-gray-800/50 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search settings"
                  className="w-full bg-gray-800/50 text-white pl-10 pr-4 py-2.5 rounded-lg border border-gray-700/50 focus:border-emerald-500/50 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none transition-all placeholder:text-gray-500"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              <div className="p-6 space-y-8">
                <nav className="grid grid-cols-2 gap-2">
                  {['general', 'interface', 'model', 'chats', 'account', 'about'].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveSettingsTab(tab)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 ${
                        activeSettingsTab === tab
                          ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/20 shadow-lg shadow-emerald-500/10 glow-effect'
                          : 'text-gray-400 hover:text-emerald-400 hover:bg-gray-800/50 border border-transparent'
                      }`}
                    >
                      {tab === 'general' && <Settings className="w-4 h-4" />}
                      {tab === 'interface' && <Monitor className="w-4 h-4" />}
                      {tab === 'model' && <Cpu className="w-4 h-4" />}
                      {tab === 'chats' && <MessageSquare className="w-4 h-4" />}
                      {tab === 'account' && <User className="w-4 h-4" />}
                      {tab === 'about' && <Info className="w-4 h-4" />}
                      <span className="capitalize text-sm">{tab}</span>
                    </button>
                  ))}
                </nav>

                <div className="space-y-8 settings-content-enter">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-emerald-400">Theme</h3>
                    <div className="grid grid-cols-3 gap-3">
                      {['System', 'Dark', 'Light'].map((t) => (
                        <button
                          key={t}
                          onClick={() => setTheme(t.toLowerCase())}
                          className={`px-4 py-2.5 rounded-lg transition-all duration-300 text-sm ${
                            theme === t.toLowerCase()
                              ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/20 shadow-lg shadow-emerald-500/10 glow-effect'
                              : 'bg-gray-800/50 text-gray-300 hover:bg-gray-700/50 border border-gray-700/50 hover:border-emerald-500/30'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-emerald-400">Language</h3>
                    <div className="relative">
                      <select
                        value={language}
                        onChange={(e) => setLanguage(e.target.value)}
                        className="w-full bg-gray-800/50 text-white px-4 py-2.5 rounded-lg appearance-none cursor-pointer hover:bg-gray-700/50 border border-gray-700/50 focus:border-emerald-500/50 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none transition-all"
                      >
                        {languages.map((lang) => (
                          <option key={lang} value={lang} className="bg-gray-900">{lang}</option>
                        ))}
                      </select>
                      <ArrowRight className="absolute right-4 top-1/2 transform -translate-y-1/2 rotate-90 w-4 h-4 text-gray-400 pointer-events-none" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 rounded-lg bg-gray-800/50 border border-gray-700/50 hover:border-emerald-500/30 transition-all">
                      <div>
                        <h3 className="text-lg font-semibold text-emerald-400">Notifications</h3>
                        <p className="text-sm text-gray-400">Enable or disable notifications</p>
                      </div>
                      <button
                        onClick={() => setNotifications(!notifications)}
                        className={`relative w-12 h-6 rounded-full transition-all duration-300 ${
                          notifications ? 'bg-emerald-600 glow-effect' : 'bg-gray-600'
                        }`}
                      >
                        <div
                          className={`absolute w-4 h-4 bg-white rounded-full top-1 transition-all duration-300 ${
                            notifications ? 'left-7' : 'left-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-gray-800/50 bg-gray-900/50 backdrop-blur-sm">
              <button 
                className="w-full px-4 py-3 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white font-semibold transition-all duration-300 hover:shadow-lg hover:shadow-emerald-500/25"
                onClick={() => setIsSettingsOpen(false)}
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <LanguageContext.Provider value={{ language, setLanguage }}>
        <div className="min-h-screen bg-black overflow-hidden relative">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="particle absolute w-2 h-2 bg-emerald-500/20 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `float ${5 + Math.random() * 10}s linear infinite`,
                animationDelay: `-${Math.random() * 10}s`
              }}
            />
          ))}
          
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_-20%,#1a472a_0,#000000_50%,#000000_100%)] animate-pulse-slow" />
          
          <div className="absolute top-20 left-20 w-72 h-72 bg-emerald-900/20 rounded-full blur-3xl animate-float">
            <div className="absolute inset-0 bg-emerald-500/10 rounded-full blur-3xl animate-trail" />
          </div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-emerald-900/20 rounded-full blur-3xl animate-float-delayed">
            <div className="absolute inset-0 bg-emerald-500/10 rounded-full blur-3xl animate-trail-delayed" />
          </div>
          
          <header className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${scrolled ? 'bg-black/80 backdrop-blur-lg' : ''}`}>
            <nav className="container mx-auto px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bot className="w-8 h-8 text-emerald-400" />
                  <span className="text-white font-bold text-xl">AI Builder</span>
                </div>

                <div className="hidden md:flex items-center gap-8">
                  <NavLink icon={<Sparkles className="w-4 h-4" />} text="Features" />
                  <NavLink icon={<Code className="w-4 h-4" />} text="Templates" />
                  <NavLink icon={<BookOpen className="w-4 h-4" />} text="Docs" />
                  <NavLink icon={<MessageSquare className="w-4 h-4" />} text="Support" />
                  <button
                    onClick={() => setIsSettingsOpen(true)}
                    className="text-emerald-100 hover:text-emerald-400 transition-colors"
                  >
                    <Settings className="w-5 h-5" />
                  </button>
                  <button className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white font-semibold transition-all hover:scale-105">
                    Get Started
                  </button>
                </div>

                <div className="md:hidden flex items-center gap-4">
                  <button
                    onClick={() => setIsSettingsOpen(true)}
                    className="text-emerald-100 hover:text-emerald-400 transition-colors"
                  >
                    <Settings className="w-5 h-5" />
                  </button>
                  <button 
                    className="text-white"
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                  >
                    {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                  </button>
                </div>
              </div>

              {isMenuOpen && (
                <div className="md:hidden absolute top-full left-0 right-0 bg-black/95 backdrop-blur-lg border-t border-emerald-900/20">
                  <div className="container mx-auto px-6 py-4 flex flex-col gap-4">
                    <NavLink icon={<Sparkles className="w-4 h-4" />} text="Features" mobile />
                    <NavLink icon={<Code className="w-4 h-4" />} text="Templates" mobile />
                    <NavLink icon={<BookOpen className="w-4 h-4" />} text="Docs" mobile />
                    <NavLink icon={<MessageSquare className="w-4 h-4" />} text="Support" mobile />
                    <button className="w-full px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white font-semibold transition-all">
                      Get Started
                    </button>
                  </div>
                </div>
              )}
            </nav>
          </header>

          <SettingsPanel />
          
          <main className="relative z-10">
            <section className="container mx-auto px-6 pt-32 pb-20">
              <div className="max-w-5xl mx-auto text-center">
                <div className="flex justify-center mb-8 animate-bounce">
                  <div className="relative">
                    <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-full animate-pulse" />
                    <Bot className="w-20 h-20 text-emerald-400 relative z-10" />
                  </div>
                </div>
                
                <h1 className="text-7xl font-bold mb-8 bg-gradient-to-r from-emerald-400 via-green-300 to-emerald-400 text-transparent bg-clip-text animate-gradient">
                  Build Your Website with AI Magic
                </h1>
                
                <div className="backdrop-blur-lg bg-white/5 rounded-2xl p-8 border border-emerald-900/20 shadow-2xl">
                  <p className="text-2xl text-emerald-100 mb-12 leading-relaxed">
                    Transform your ideas into stunning websites in minutes. Let our AI craft the perfect launch page while you focus on what matters most.
                  </p>
                  
                  <button className="group relative px-8 py-4 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xl font-bold text-white transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/25">
                    <span className="flex items-center gap-2">
                      Start Creating Now
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </span>
                    <div className="absolute inset-0 bg-emerald-400/20 blur-xl rounded-xl group-hover:bg-emerald-400/40 transition-all" />
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
                  <div className="backdrop-blur-lg bg-white/5 rounded-xl p-6 border border-emerald-900/20 transform hover:-translate-y-2 transition-all duration-300">
                    <Zap className="w-8 h-8 text-emerald-400 mx-auto mb-4" />
                    <div className="text-4xl font-bold text-white mb-2">2 Minutes</div>
                    <div className="text-emerald-300">Average Build Time</div>
                  </div>
                  <div className="backdrop-blur-lg bg-white/5 rounded-xl p-6 border border-emerald-900/20 transform hover:-translate-y-2 transition-all duration-300">
                    <div className="text-4xl font-bold text-white mb-2">100%</div>
                    <div className="text-emerald-300">AI Powered</div>
                  </div>
                  <div className="backdrop-blur-lg bg-white/5 rounded-xl p-6 border border-emerald-900/20 transform hover:-translate-y-2 transition-all duration-300">
                    <div className="text-4xl font-bold text-white mb-2">24/7</div>
                    <div className="text-emerald-300">Instant Creation</div>
                  </div>
                </div>
              </div>
            </section>

            <section className="py-20 relative">
              <div className="container mx-auto px-6">
                <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-emerald-400 via-green-300 to-emerald-400 text-transparent bg-clip-text animate-gradient">
                  Powerful AI Features
                </h2>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                  <div className="space-y-8">
                    {features.map((feature, index) => (
                      <div
                        key={index}
                        className={`group cursor-pointer backdrop-blur-lg rounded-xl p-6 transition-all duration-300 ${
                          activeFeature === index
                            ? 'bg-emerald-900/30 border border-emerald-500/30'
                            : 'bg-white/5 border border-emerald-900/20 hover:bg-emerald-900/20'
                        }`}
                        onClick={() => setActiveFeature(index)}
                      >
                        <div className="flex items-start gap-4">
                          {feature.icon}
                          <div>
                            <h3 className="text-xl font-semibold text-emerald-300 mb-2">{feature.title}</h3>
                            <p className="text-emerald-100/80">{feature.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="relative aspect-video rounded-xl overflow-hidden">
                    {features.map((feature, index) => (
                      <div
                        key={index}
                        className={`absolute inset-0 transition-opacity duration-500 ${
                          activeFeature === index ? 'opacity-100' : 'opacity-0'
                        }`}
                      >
                        <img
                          src={feature.image}
                          alt={feature.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            <section className="py-20 relative overflow-hidden">
              <div className="container mx-auto px-6">
                <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-emerald-400 via-green-300 to-emerald-400 text-transparent bg-clip-text animate-gradient">
                  See It In Action
                </h2>
                
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/20 to-green-900/20 backdrop-blur-xl rounded-2xl" />
                  <div className="relative rounded-2xl overflow-hidden border border-emerald-500/20">
                    <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[600px]">
                      <div className="p-8 flex flex-col justify-center">
                        <div className="space-y-6">
                          {demoSteps.map((step, index) => (
                            <div
                              key={index}
                              className={`transition-all duration-500 ${
                                activeDemo === index
                                  ? 'opacity-100 transform translate-x-0'
                                  : 'opacity-50 transform -translate-x-4'
                              }`}
                            >
                              <div className="flex items-center gap-4">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                  activeDemo === index ? 'bg-emerald-500' : 'bg-emerald-900'
                                }`}>
                                  {index + 1}
                                </div>
                                <div>
                                  <h3 className="text-xl font-semibold text-emerald-300">{step.title}</h3>
                                  <p className="text-emerald-100/80">{step.description}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="relative h-full min-h-[400px]">
                        {demoSteps.map((step, index) => (
                          <div
                            key={index}
                            className={`absolute inset-0 transition-opacity duration-1000 ${
                              activeDemo === index ? 'opacity-100' : 'opacity-0'
                            }`}
                          >
                            <img
                              src={step.preview}
                              alt={step.title}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-transparent" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="py-20 relative">
              <div className="container mx-auto px-6">
                <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-emerald-400 via-green-300 to-emerald-400 text-transparent bg-clip-text animate-gradient">
                  Why Choose Our AI Builder
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {benefits.map((benefit, index) => (
                    <div
                      key={index}
                      className="group backdrop-blur-lg bg-white/5 rounded-xl p-8 border border-emerald-900/20 hover:border-emerald-500/30 transition-all duration-300 hover:-translate-y-2"
                    >
                      <div className="text-emerald-400 mb-6 group-hover:scale-110 transition-transform">
                        {benefit.icon}
                      </div>
                      <h3 className="text-xl font-semibold text-white mb-4">{benefit.title}</h3>
                      <p className="text-emerald-100/80">{benefit.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            <section className="py-20 relative">
              <div className="container mx-auto px-6">
                <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-emerald-400 via-green-300 to-emerald-400 text-transparent bg-clip-text animate-gradient">
                  How It Works
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <StepCard
                    number="01"
                    icon={<Laptop className="w-8 h-8" />}
                    title="Describe Your Vision"
                    description="Tell our AI what kind of website you need, your brand, and your goals."
                  />
                  <StepCard
                    number="02"
                    icon={<Wand2 className="w-8 h-8" />}
                    title="AI Generation"
                    description="Watch as AI creates your custom website with optimized layouts and content."
                  />
                  <StepCard
                    number="03"
                    icon={<Gauge className="w-8 h-8" />}
                    title="Instant Deploy"
                    description="Your website goes live instantly with all the features you need."
                  />
                </div>
              </div>
            </section>

            <section className="py-20 relative">
               ```
              <div className="container mx-auto px-6">
                <div className="relative rounded-2xl overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-900 to-green-900 opacity-90" />
                  <div className="relative z-10 py-16 px-8 text-center">
                    <h2 className="text-4xl md:text-5xl font-bold mb-8 text-white">
                      Ready to Build Your Website?
                    </h2>
                    <p className="text-xl text-emerald-100 mb-12 max-w-2xl mx-auto">
                      Join thousands of creators who have already built their perfect website using our AI technology.
                    </p>
                    <button className="group relative px-8 py-4 bg-white text-emerald-900 rounded-xl text-xl font-bold transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/25">
                      <span className="flex items-center gap-2">
                        Start Building Free
                        <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </section>
          </main>
        </div>
      </LanguageContext.Provider>
    </ThemeContext.Provider>
  );
}

export default App;